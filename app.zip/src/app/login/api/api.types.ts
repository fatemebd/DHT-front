import { User } from "@/@types/common";

export interface PreSignup {
  email: string;
}

export interface SignupInfo {
  email: string;
  otp: string;
}


