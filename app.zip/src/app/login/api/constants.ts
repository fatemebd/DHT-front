export const POST_LOGIN_EMAIL = "/users/login/";
export const POST_OTP = "/users/login/verify-otp/";
