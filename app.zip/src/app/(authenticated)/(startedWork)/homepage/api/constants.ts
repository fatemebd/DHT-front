export const GET_TO_DO_LIST = "/habits/todo/";
export const GET_HABITS_LIST = "/habits/user/list/";
export const GET_REMINDERS_LIST = "/habits/reminder/list/";