import type { NextPage } from "next";
import { useEffect, useState } from "react";
import { Row, Col, Typography } from "antd";
import jalaali from "jalaali-js";

interface DataItem {
  date: string;
  value: number;
  jalaliDate: string;
  dayIndex: number;
}

const Home: NextPage = () => {
  const [data, setData] = useState<DataItem[]>([]);

  // Jalali weekdays starting with Saturday
  const jalaliWeekdays = ["ش", "ی", "د", "س", "چ", "پ", "ج"];

  useEffect(() => {
    // Map your data and convert the dates
    const mappedData = [
      { date: "8/13/2023", value: 66 },
      { date: "8/26/2023", value: 1 },
      { date: "8/12/2023", value: 15 },
      { date: "8/13/2023", value: 50 },
      { date: "8/8/2023", value: 60 },
      { date: "8/8/2023", value: 24 },
      { date: "8/23/2023", value: 23 },
      { date: "8/15/2023", value: 68 },
      { date: "8/19/2023", value: 88 },
      { date: "8/20/2023", value: 10 },
      { date: "8/1/2023", value: 33 },
      { date: "8/7/2023", value: 44 },
      { date: "8/9/2023", value: 24 },
      { date: "8/22/2023", value: 71 },
      { date: "8/25/2023", value: 91 },
      { date: "8/29/2023", value: 0 },
      { date: "8/7/2023", value: 79 },
      { date: "8/28/2023", value: 63 },
      { date: "8/20/2023", value: 83 },
      { date: "8/27/2023", value: 67 },
      { date: "8/10/2023", value: 31 },
      { date: "8/13/2023", value: 71 },
      { date: "8/1/2023", value: 64 },
      { date: "8/26/2023", value: 22 },
      { date: "8/20/2023", value: 54 },
      { date: "8/9/2023", value: 94 },
      { date: "8/10/2023", value: 22 },
      { date: "8/11/2023", value: 98 },
      { date: "8/15/2023", value: 97 },
      { date: "8/18/2023", value: 81 },
    ].map((item) => {
      const [month, day, year] = item.date.split("/").map(Number);
      const date = new Date(year, month - 1, day);
      const jalali = jalaali.toJalaali(date);
      const dayOfWeek = (date.getDay() + 1) % 7; // Adjusting day of the week to match Jalali starting with Saturday
      return {
        ...item,
        jalaliDate: `${jalali.jYear}/${jalali.jMonth}/${jalali.jDay}`,
        dayIndex: dayOfWeek,
      };
    });
    setData(mappedData);
  }, []);

  return (
    <div className="pr-[15%]  bg-white bg-opacity-5 p-3 text-center rounded-lg mt-4 w-full">
      <Row
        // justify="center"
        gutter={[8, 8]}
        className="text-white text-center w-full"
      >
        {jalaliWeekdays.map((day, index) => (
          <Col key={day} span={3}>
            <Typography className="text-white">{day}</Typography>
          </Col>
        ))}
      </Row>

      {Array.from({ length: 5 }, (_, k) => k * 7).map((startIndex) => (
        <Row
          //   justify="center"
          key={startIndex}
          gutter={[16, 16]}
          wrap={true}
          className="w-full"
        >
          {data.slice(startIndex, startIndex + 7).map((item) => (
            <Col
              key={`${item}`}
              span={3}
              className="flex flex-col items-center w-full"
            >
              <div
                className="w-full md:h-8 sm:h-10 h-8 md:m-2 m-0.5 rounded-md"
                style={{
                  backgroundColor: `rgba(115, 57, 237, ${item.value / 100})`,
                }}
              />
            </Col>
          ))}
        </Row>
      ))}
    </div>
  );
};

export default Home;
