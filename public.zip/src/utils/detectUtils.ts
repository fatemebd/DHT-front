export const isClient = () => typeof window !== "undefined";
