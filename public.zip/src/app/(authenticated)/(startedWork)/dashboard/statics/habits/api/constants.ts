export const GET_DAILY_HABITS= "/habits/report/daily/";
export const GET_WEEKLY_HABITS ="/habits/report/weekly/"