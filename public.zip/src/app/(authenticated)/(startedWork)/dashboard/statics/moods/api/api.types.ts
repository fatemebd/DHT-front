export interface MoodReportItem {
  name: "verySad"|"sad"|"neutral"|"happy"|"thrilled";
  value: number;
}
