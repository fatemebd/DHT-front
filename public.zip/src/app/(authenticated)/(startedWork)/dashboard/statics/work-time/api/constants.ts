export const GET_DAILY_WORK_TIME = "/habits/work-report/daily/";
export const GET_WEEKLY_WORK_TIME = "/habits/work-report/weekly/";