import fa from "../fa.json";

export const tableColumns = () => [
  {
    title: fa.name,
    dataIndex: "name",
    key: "name",
  },
  {
    title: fa.description,
    dataIndex: "description",
    key: "description",
  },
];
