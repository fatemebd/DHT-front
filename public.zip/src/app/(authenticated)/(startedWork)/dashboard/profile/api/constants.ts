export const PUT_USER_PROFILE = "/users/profile/";
export const PUT_USER_PROFILE_PICTURE = "/users/profile/picture/";