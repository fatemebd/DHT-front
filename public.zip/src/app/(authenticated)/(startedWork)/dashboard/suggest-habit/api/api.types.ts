export interface Suggestion {
  name: string;
  description?: string;
  score?: number;
}
