export const GET_FEATURES_LIST = "/scoring/feature/list/";
export const BUY_FEATURE = (id: number) => `/scoring/feature/purchase/${id}/`;
