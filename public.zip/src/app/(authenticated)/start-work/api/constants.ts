export const START_WORK = "/habits/start-work/";
export const END_WORK = "/habits/end-work/";

export const LOG_OUT = "/users/logout/";